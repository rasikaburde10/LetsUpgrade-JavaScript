console.log("This is the 1st Assignment for day 1");

var n1;
function r(n1,n)
{
    return Array(n-n1+1).fill().map((_,idx)=>n1+idx);
}
var result=prompt("Enter start and end");
var r1=result.split(' ');
var r2=r1[0];
var r3=r1[1];
var res=r(+r2,+r3);
console.log(res);
  var odd= res.filter((el)=>el%2!=0);
  console.log(odd);

  for(var i=0;i<odd.length;i++)
  {
      odd[i]=odd[i]*odd[i]*odd[i];

  }
  console.log(odd);
