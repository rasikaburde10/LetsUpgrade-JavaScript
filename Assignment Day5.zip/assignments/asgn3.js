console.log("This is 3rd assignment for day5");
//  async function fetchjokes()
//  {
//     const response=await fetch('​https://jsonplaceholder.typicode.com/todos');
//      //const data=await response.json();
//      //console.log(data);
//  }

//  fetchjokes();

//fetch('https://jsonplaceholder.typicode.com/todos').then(response=>response.json()).then(data=>console.log(data))
fetch('https://jsonplaceholder.typicode.com/todos/1')
  .then(response => response.json())
  .then(json => console.log(json));

  async function todo()
  {
      const response=await fetch('https://jsonplaceholder.typicode.com/todos');
      const data= await response.json();
      console.log(data);
  }
  todo();

