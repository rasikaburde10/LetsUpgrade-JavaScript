console.log("This is 3rd Assignment  of Day 3");
//console.log("USING IF ESLE IF");
var m=prompt("Enter Marks");
if(m>=90)
{
    var g="O";
}
else if(m>=80 && m<90)
{
    var g="A+";
}
else if(m>=70 && m<80)
{
    var g="A";
}
else if(m>=60 && m<70)
{
    var g="B+";
}
else if(m>=50 && m<60)
{
    var g="B";
}
else if(m>=40 && m<50)
{
    var g="C";
}
else
{
    var g="F";
}
console.log(`Marks are ${m} and grade is ${g}`);


