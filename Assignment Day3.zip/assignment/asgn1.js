console.log("This is 1st Assignment of Day 3");
var n=prompt("Enter a Number");
//console.log(n);
let find=function(n)
{
    if ((n%2)==0) {
        var res=`The number enterd is ${n} and Number is even`;
        
    } else {
        var res=`The number enterd is ${n} and Number is odd`;
    }
    console.log(res);

}
find(n);