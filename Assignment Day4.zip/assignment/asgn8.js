function ask(question,yes,no)
{
    if(confirm(question))
    yes()
    else
    no();
}

ask(
    "Do You Agree?",
    ()=>alert("You Agreed."),
    ()=>alert("You Cancelled the Execution.")
);