console.log("This is 2nd assignmnet for Day 4");

 const student={
     name:"Helsinki",
     age:24,
     projects:{
        dicegame:"Two player dice game using java script"
     }
 }


// Destructuring::


const{name,age,projects:{dicegame}}=student;
console.log(name,age,dicegame);
