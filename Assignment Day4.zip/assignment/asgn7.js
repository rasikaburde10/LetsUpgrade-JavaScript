console.log("This is 7th Assignment for Day4");

let n=prompt("Enter a value");
nextPrime:
for(let i=2;i<=n;i++)
{
    for(let j=2;j<i;j++)
    {
        if(i%j==0)
        continue nextPrime;
    }
    console.log(i);
}
