console.log("This is 4th assignment for Day4");

let s=prompt("Enter\r\n 1.Addition\r\n 2.Subtraction\r\n 3.Multiply\r\n 4.Division\r\n  5.Perentage");
console.log(s);
let a=prompt("Enter 1st operand");
let b=prompt("Enter 2nd operand");

switch(+s)
{
    case 1:
        var r=+a + +b;
        break;
    case 2:
        var r=+ a - +b;
        break;
    case 3:
        var r=+a * +b;
        break;
    case 4:
        var r=+a / +b;
        break;
    case 5:
        var r=+a % +b;  
        break;
    default:
        var r=-1;
        break;
}

console.log("result is",r);
