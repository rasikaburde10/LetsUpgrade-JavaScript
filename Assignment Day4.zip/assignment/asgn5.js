console.log("This is 5th assignment for Day4");
var s=prompt("Enter Your sales amount");

if(+s>0 && +s<=5000)
var r=(0.02 * +s);

else if(+s>5000 && +s<=10000)
var r=(0.05 * +s);

else if(+s>10000 && +s<=20000)
var r=(0.07 * +s);

else 
var r=(0.10 * +s);

console.log("Tptal profit from sales is:",r);