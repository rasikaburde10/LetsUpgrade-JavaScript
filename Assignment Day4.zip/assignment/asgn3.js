console.log("This is 3rd Assignment for day3")


let shoppingList=["Eggs","Bread","Butter","Biscuits","Meat","Soaps","Grooming Kit"];

let shoppingBasket=[...shoppingList,"Fruits","Vegetables","Cooking Oil","Snaitizers","Cutlery"];


console.log(shoppingBasket);
