console.log("This is 6th Assignment for Day4");
let n;
do{
 n=prompt("Enter a number greater than 100");

}while(n <= 100 && n);
