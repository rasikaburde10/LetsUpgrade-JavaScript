console.log("Methods of Strings");

let name="Rio";
let skill="hacking";
let weakness="tokyo";
let text="The quick brown fox jumps over the wall";

//charCodeAt()
//gives the unicode of last charachter in string
var n=skill.charCodeAt(skill.length-1);
console.log(n);


//endswith()
//checks if given string ends with a specified string
var n1=text.endsWith("wall");
console.log(n1);

//includes()
//checks wether a string contains specified string/character
var n2=text.includes("brown");
console.log(n2);

//match()
//searches a string for a match against a regular expression and returns the matches, as an array object.
var n3=text.match(/o/g);
console.log(n3);


//search()
//searches a specified value/string
var n4=text.search("all");
console.log(n4);

//slice()
//Extract parts of a string
var n5=weakness.slice(0,4);
console.log(n5);

//Split a string into an array of substrings
var n6=text.split(" ");
console.log(n6);



//substr()
//Extracts the characters from a string, beginning at a specified start position, and through the specified number of character
var str="Hello World!";
var n7=str.substr(1,4);
console.log(n7);


//trim()
//remove whitespace from both sides of string
var str1="    Hello World!   ";
var n8=str1.trim();
console.log(n8);


//replace
//Searches a string for a specified value, or a regular expression, and returns a new string where the specified values are replaced
var n9=text.replace("quick","slow");
console.log(n9);


//Array
let arr=["one","two","three"];

let arr2=['rio','berlin','alacia'];

//splice

arr.splice(1,1);//from 1st index remove 1 element
console.log(arr);//we removed "two"
console.log(arr);

arr.splice(1,0,"two");//from 1st index remove 0 element and replace it with two
console.log(arr);




//slice
//It returns a new array copying to it all items from index start to end (not including end)
var v1= arr2.slice(1,3);
console.log(v1);
//console.log(arr2);




//find




//findIndex




//map



//sort
arr3=[1,2,15];
arr3.sort();
console.log(arr3);


//split
let s="test";
s.split('');
console.log(s);


//join
let s1=["ABC","XYZ","PQR"];
console.log(s1);
let s2=s1.join('');
console.log(s2);s


//reduce


























