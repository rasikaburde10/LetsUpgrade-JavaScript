console.log("hello");
var name=prompt("Please Enter your name");
console.log(name);