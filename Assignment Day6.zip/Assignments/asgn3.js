const name=prompt("Enter Your name","Anonymous");
title.innerHTML+=`Welcome to our page ${name}`;

const ctime=document.getElementById('time');
function clock()
{
    let date=new Date();
    let time=date.toLocaleTimeString();
    ctime.innerText=time;


}

const dmode=document.getElementById('dark');
function myfunc()
{
    dmode.classList.toggle("mystyle");
    changeColor();
   
}
function changeColor()
{
    setTimeout(()=>{
        document.body.style.backgroundColor='black';
        document.body.style.color='white';
        document.body.style.fontFamily='Helvetica';
    },300);
    
}

//clock();
setInterval(clock,1000);
myfunc();
